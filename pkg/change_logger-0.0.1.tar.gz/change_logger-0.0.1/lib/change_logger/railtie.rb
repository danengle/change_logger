require 'change_logger'

module ChangeLogger
  class Railtie < Rails::Railtie
    
  end
end